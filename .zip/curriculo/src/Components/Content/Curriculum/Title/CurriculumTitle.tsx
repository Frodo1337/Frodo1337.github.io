const CurriculumTitle = () => {
    return (
        <div>
            <h3>
                Matheus Wilhelm Siqueira
            </h3>
            <span>
                Cientista da Computação
            </span>
        </div>
        
    )
}

export default CurriculumTitle;