const CurriculumInfo = () => {
    return (
        <div>
            <h4>
                Perfil
            </h4>
            <h4>
                Experiência
            </h4>
            <h4>
                Formação
            </h4>
            <h4>
                Competências
            </h4>
            <h4>
                Atividades Extracurriculares
            </h4>
        </div>
    );
}

export default CurriculumInfo;