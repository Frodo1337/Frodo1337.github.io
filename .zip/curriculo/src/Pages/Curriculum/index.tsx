import Curriculum from "./Curriculum";

export default Curriculum;