enum ThemeEnum {
    Dark = 0,
    Light = 1
}

export default ThemeEnum;