enum LanguageEnum {
    Portuguese = 0,
    English = 1
}

export default LanguageEnum;